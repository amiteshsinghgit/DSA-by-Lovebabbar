# LIST OF SOLVED QUESTIONS

1.
    ```
    Write a program to reverse an integer. (Leetcode : Problem No 7)
    ```
    
2.
    ```
    Write a program to find the complement of a base 10 integer. (Leetcode : Problem No 1009)
    ```
    
3.
    ```
    Write a program to check whether the given number is a power of two or not. (Leetcode : Problem No 231)
    ```
