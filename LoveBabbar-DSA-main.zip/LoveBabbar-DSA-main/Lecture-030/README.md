# LIST OF SOLVED QUESTIONS

1.
    ```
    Write a program to introduce macros.
    ```

2.
    ```
    Write a program to introduce global variables.
    ```

3.
    ```
    Write a program to introduce inline functions.
    ```

4.
    ```
    Write a program to introduce default arguments.
    ```
