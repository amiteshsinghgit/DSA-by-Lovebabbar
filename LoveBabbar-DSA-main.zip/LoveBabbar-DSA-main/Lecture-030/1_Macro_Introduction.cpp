#include <bits/stdc++.h>
using namespace std;

#define PI 3.14

int main() {
    int radius = 5;
    // double PI = 3.14;

    double area = PI * radius * radius;
    cout << "Area is : " << area << endl;

    return 0;
}