# LIST OF SOLVED QUESTIONS

1.
    ```
    Write a program to implement array STL in CPP.
    ```

2.
    ```
    Write a program to implement vector STL in CPP.
    ```

3.
    ```
    Write a program to implement deque STL in CPP.
    ```

4.
    ```
    Write a program to implement list STL in CPP.
    ```

5.
    ```
    Write a program to implement stack STL in CPP.
    ```

6.
    ```
    Write a program to implement queue STL in CPP.
    ```

7.
    ```
    Write a program to implement priority queue STL in CPP.
    ```

8.
    ```
    Write a program to implement set STL in CPP.
    ```

9.
    ```
    Write a program to implement map STL in CPP.
    ```

10.
    ```
    Write a program to implement algorithm STL in CPP.
    ```
