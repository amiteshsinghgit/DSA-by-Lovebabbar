#include <iostream>
#include <set>
using namespace std;

int main() {
    set<int> q;
    
    return 0;
}