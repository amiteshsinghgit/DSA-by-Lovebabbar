#include <iostream>
#include <queue>
using namespace std;

int main() {
    priority_queue<int> q;
    
    return 0;
}