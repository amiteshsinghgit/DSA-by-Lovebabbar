#include <iostream>
#include <map>
using namespace std;

int main() {
    map<int, string> q;
    
    return 0;
}