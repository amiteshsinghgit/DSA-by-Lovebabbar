# LIST OF SOLVED QUESTIONS

1.
    ```
    Write a program to introduce character arrays.
    ```
2.
    ```
    Write a program to find the length of a string without using in-built function.
    ```
3.
    ```
    Write a program to reverse a string without using in-built function. (Leetcode : Problem No 344)
    ```
4.
    ```
    Write a program to check whether a string is palindrome or not.
    ```
5.
    ```
    Write a program to check whether a string is (non-case sensitive) palindrome or not (I).
    ```
6.
    ```
    Write a program to check whether a string is (non-case sensitive) palindrome or not (II). (Leetcode : Problem No 125)
    ```
7.
    ```
    Write a program to reverse words in a string. (Leetcode : Problem No 151)
    ```
8.
    ```
    Write a program to get the maximum occurred character in a string.
    ```
9.
    ```
    Write a program to replace spaces in a string with @40.
    ```
10.
    ```
    Write a program to remove all occurrences of a given substring from a string. (Leetcode : Problem No 1910)
    ```
11.
    ```
    Write a program to check the presence of any permutation of a string within another entered string. (Leetcode : Problem No 567)
    ```
12.
    ```
    Write a program to remove all adjacent duplicate characters from a string. (Leetcode : Problem No 1047)
    ```
13.
    ```
    Write a program to create a compressed string according to the count of characters. (Leetcode : Problem No 443)
    ```
