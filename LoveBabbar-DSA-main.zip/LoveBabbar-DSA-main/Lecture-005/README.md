# LIST OF SOLVED QUESTIONS

1.  
    ```
    Write a program to show the working of bitwise operators.
    ```

2.  
    ```
    Write a program to show the working of left and right shift operators.
    ```
    
3.  
    ```
    Write a program to show the working of increment and decrement operators.
    ```
    
4.  
    ```
    Write a program to print fibonacci series.
    ```
    
5.  
    ```
    Write a program to check whether the entered number is prime or not.
    ```
    
6.
    ```
    Write a program to subtract the product and sum of digits of an integer. (Leetcode : Problem No 1281)
    ```
    
7.
    ```
    Write a program to count the number of 1 bits (setbits) in a given number. (Leetcode : Problem No 191)
    ```
