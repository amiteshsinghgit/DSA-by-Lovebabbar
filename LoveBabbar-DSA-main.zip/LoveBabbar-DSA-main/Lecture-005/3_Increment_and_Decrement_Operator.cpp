#include <iostream>
using namespace std;

int main() {
    int i = 10;

    cout << "Pre-Increment i = " << ++i << endl;

    cout << "Post-Increment i = " << i++ << endl;

    cout << "Pre-Decrement i = " << --i << endl;

    cout << "Post-Decrement i = " << i-- << endl;
    
    return 0;
}