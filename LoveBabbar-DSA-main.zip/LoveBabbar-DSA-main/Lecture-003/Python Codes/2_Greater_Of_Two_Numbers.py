a = int(input("Enter the value of a : "))
b = int(input("Enter the value of b : "))

if a>b:
    print("a is greater!")
else:
    print("b is greater!")