ch = str(input("Enter the value of ch : "))

if (ch>='A' and ch<='Z'):
    print("Uppercase Character !")
elif(ch>='a' and ch<='z'):
    print("Lowercase Character !")
else:
    print("Number !")
    