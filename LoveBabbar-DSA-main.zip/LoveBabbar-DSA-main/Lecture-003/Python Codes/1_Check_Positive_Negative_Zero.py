n = int(input("Enter the value of n : "))

if n < 0:
    print("n is negative !")
elif n>0:
    print("n is positive !")
else:
    print("n is zero !")