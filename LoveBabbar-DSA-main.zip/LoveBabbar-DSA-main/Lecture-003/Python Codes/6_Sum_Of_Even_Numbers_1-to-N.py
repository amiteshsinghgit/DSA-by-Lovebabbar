n = int(input("Enter the value of n : "))
sum = 0
i = 0
while i<=n:
    sum += i
    i += 2
print("Sum of even numbers upto n :", sum)