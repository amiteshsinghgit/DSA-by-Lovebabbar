f = int(input("Enter the temperature in fahrenheit : "))
c = ((f-32) * 5) / 9
print("Temperature in celsius :", c)