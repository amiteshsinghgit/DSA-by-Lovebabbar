# LIST OF SOLVED QUESTIONS

1.  
    ```
    Write a program to check whether the entered number is a positive number, zero or a negative number.
    ```

2.  
    ```
    Write a program to find the greater of two entered numbers.
    ```
    
3.  
    ```
    Write a program to check whether the entered character is uppercase alphabet, lowercase or a number.
    ```
    
4.  
    ```
    Write a program to display the counting number from 1 to n.
    ```
    
5.  
    ```
    Write a program to find the sum of all numbers from 1 to n.
    ```
    
6.
    ```
    Write a program to find the sum of all even numbers from 1 to n.
    ```

7.
    ```
    Write a program to convert temperature from fahrenheit to celsius.
    ```

8.
    ```
    Write a program to print the following pattern (for n=4) :
    
        * * * *
        * * * *
        * * * *
        * * * *
    ```

9.
    ```
    Write a program to print the following pattern (for n=4) :
    
        1 1 1 1
        2 2 2 2
        3 3 3 3
        4 4 4 4
    ```

