#include <bits/stdc++.h>
using namespace std;

int minimumCost(string str) {
    
}

int main() {
    string str;
    cout << "Enter the string : ";
    getline(cin, str);

    cout << "Required mimnimum cost : " << minimumCost(str) << endl;

    return 0;
}