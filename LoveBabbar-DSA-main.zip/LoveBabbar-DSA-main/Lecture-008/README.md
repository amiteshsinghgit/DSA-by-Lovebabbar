# LIST OF SOLVED QUESTIONS

1.
    ```
    Write a program to introduce switch-case.
    ```
    
2.
    ```
    Write a program to show the working of switch-case in an infinite loop.
    ```
    
3.
    ```
    Write a program for a calculator based on switch-case.
    ```

4.
    ```
    Write a program to disribute an amount in notes of different values using switch-case.
    ```

5.
    ```
    Write a program to introduce functions.
    ```

6.
    ```
    Write a program to check whether a given number is even or odd using functions.
    ```

7.
    ```
    Write a program to calculate the value of nCr with given n & r using functions.
    ```

8.
    ```
    Write a program to print counting using functions.
    ```

9.
    ```
    Write a program to check whether a given number is prime or not using functions.
    ```

10.
    ```
    Write a program to calculate the nth term of an AP (3*n + 7).
    ```

11.
    ```
    Write a program to count the total number of setbits of two numbers using functions.
    ```
    
12.
    ```
    Write a program to find the nth term of fibonacci series.
    ```

13.
    ```
    Write a program to display the working of "pass by value" feature of functions.
    ```
