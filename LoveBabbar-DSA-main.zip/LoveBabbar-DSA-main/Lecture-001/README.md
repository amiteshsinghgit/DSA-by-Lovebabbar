# First lecture is all about flowcharts and pseudocodes !
