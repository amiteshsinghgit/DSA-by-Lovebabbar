# LIST OF SOLVED QUESTIONS

1.
    ```
    Write a program to swap the alternate elements of an array.
    ```
    
2.
    ```
    Write a program to find the unique element in an array.
    ```
    
3.
    ```
    Write a program to check the number of unique occurrences in an array.
    ```

4.
    ```
    Write a program to find the duplicate element in an array.
    ```
    
5.
    ```
    Write a program to find all the duplicate elements in an array.
    ```
6.
    ```
    Write a program to find the intersection elements of two arrays.
    ```
7.
    ```
    Write a program to find the pairs of elements with given sum in an array.
    ```
8.
    ```
    Write a program to find the triplets of elements with given sum in an array.
    ```

9.
    ```
    Write a program to sort all 0 & 1 in an array.
    ```
10.
    ```
    Write a program to sort all 0, 1 & 2 in an array.
    ```
