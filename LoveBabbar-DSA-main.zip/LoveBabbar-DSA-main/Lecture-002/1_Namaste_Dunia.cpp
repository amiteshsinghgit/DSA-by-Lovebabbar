#include <iostream>
using namespace std;

int main() {
    
    cout << "Namaste Dunia" << endl;
    
}