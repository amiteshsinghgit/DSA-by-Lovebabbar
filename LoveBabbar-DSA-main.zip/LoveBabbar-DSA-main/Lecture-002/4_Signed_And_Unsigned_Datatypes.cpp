#include <iostream>
using namespace std;

int main() {
    
    unsigned int a = 112;
    cout << a << endl;

    unsigned int a1 = -112;
    cout << a1 << endl;

    signed int b = 112;
    cout << b << endl;

    signed int b1 = -112;
    cout << b1 << endl;

}