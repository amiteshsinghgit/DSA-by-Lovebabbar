public class Arithematic_Operators {
    public static void main(String args[]) throws Exception {
        int a = 50;
        int b = 20;

        System.out.println(a+b);
        System.out.println(a-b);
        System.out.println(a*b);
        System.out.println(a/b);
        System.out.println(a%b);

    }
}
