public class Namaste_Dunia {
    public static void main(String[] args) throws Exception {
        System.out.println("Namaste Dunia!");
    }
}
