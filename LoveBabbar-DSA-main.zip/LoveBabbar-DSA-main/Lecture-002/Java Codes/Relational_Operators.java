public class Relational_Operators {
    public static void main(String args[]) throws Exception {
        int a = 5;
        int b = 10;

        System.out.println(a>b);
        System.out.println(a<b);

        System.out.println(a>=b);
        System.out.println(a<=b);

        System.out.println(a!=b);
        System.out.println(a==b);

    }
}
