public class Datatypes_And_Variables {
    public static void main(String[] args) throws Exception {

        int a = 123;
        System.out.println(a);

        char ch = 'a';
        System.out.println(ch);

        float f = 1.4956F;
        System.out.println(f);

        double d = 1.4;
        System.out.println(d);

        byte b = 125;
        System.out.println(b);

        long l = 12523256225L;
        System.out.println(l);

        short s1 = 15;
        System.out.println(s1);

    }
}
