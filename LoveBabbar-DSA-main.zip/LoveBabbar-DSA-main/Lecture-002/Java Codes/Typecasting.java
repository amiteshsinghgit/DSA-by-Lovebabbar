public class Typecasting {
    public static void main(String arg[]) throws Exception {

        int a = 65;
        System.out.println(a);

        char ch = (char)a;
        System.out.println(ch);

    }
}
