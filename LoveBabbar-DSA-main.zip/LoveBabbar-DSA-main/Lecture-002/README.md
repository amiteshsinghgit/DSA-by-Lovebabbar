# LIST OF SOLVED QUESTIONS

1.  
    ```
    Write a program to print "Namaste Dunia".
    ```

2.  
    ```
    Write a program to introduce with datatypes and variables.
    ```
    
3.  
    ```
    Write a program to perform typecasting.
    ```
    
4.  
    ```
    Write a program to show the working of signed and unsigned datatypes.
    ```
    
5.  
    ```
    Write a program to show the working of arithmetic operators.
    ```
    
6.
    ```
    Write a program to show the working of relational operators.
    ```

7.
    ```
    Write a program to show the working of logical opeartors.
    ```
