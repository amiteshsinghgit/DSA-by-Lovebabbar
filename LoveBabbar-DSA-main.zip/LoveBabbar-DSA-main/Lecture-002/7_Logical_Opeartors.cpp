#include <iostream>
using namespace std;

int main() {

    int a = 0;
    cout << !a << endl;

    int b = 5;
    cout << !b << endl;
    
}