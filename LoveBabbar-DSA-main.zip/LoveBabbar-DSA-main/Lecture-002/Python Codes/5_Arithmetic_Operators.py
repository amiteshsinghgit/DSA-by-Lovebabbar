a = 23/4
print(a)

b = 23//4
print(b)
