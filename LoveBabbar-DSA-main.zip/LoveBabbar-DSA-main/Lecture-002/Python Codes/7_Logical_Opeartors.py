a = 5
b = 0

print(a and b)
print(a or b)