#include <iostream>
using namespace std;

int main() {
    
    int a = 2 / 5;
    cout << a << endl;

    float a1 = 2.0 / 5;
    cout << a1 << endl;
    
}