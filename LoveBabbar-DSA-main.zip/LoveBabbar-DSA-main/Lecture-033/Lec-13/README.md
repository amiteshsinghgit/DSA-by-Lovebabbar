# LIST OF SOLVED QUESTIONS

1.
    ```
    Write a program to find the first and last position of an element in a sorted array using recursion.
    ```

2.
    ```
    Write a program to find the total number of occurrence of an element in a sorted array using recursion.
    ```

3.
    ```
    Write a program to find the peak index of a mountain array using recursion.
    ```
