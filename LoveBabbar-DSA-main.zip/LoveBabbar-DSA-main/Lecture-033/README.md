# LIST OF SOLVED QUESTIONS

1.
    ```
    Write a program to check whether an array is sorted or not using recursion.
    ```

2.
    ```
    Write a program to find the sum of all elements of an array using recursion.
    ```

3.
    ```
    Write a program to perform linear searching using recursion on an array.
    ```

4.
    ```
    Write a program to perform binary searching using recursion on an array.
    ```
