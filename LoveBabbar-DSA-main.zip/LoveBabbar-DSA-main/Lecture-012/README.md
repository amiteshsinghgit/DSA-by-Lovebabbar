# LIST OF SOLVED QUESTIONS

1.
    ```
    Write a program to introduce binary search algorithm and perform it on an array.
    ```
