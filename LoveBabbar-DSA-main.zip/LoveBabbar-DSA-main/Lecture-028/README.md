# LIST OF SOLVED QUESTIONS

1.
    ```
    Write a program to introduce reference variables.
    ```

2.
    ```
    Write a program to declare an array dynamically and perform all its operations.
    ```
