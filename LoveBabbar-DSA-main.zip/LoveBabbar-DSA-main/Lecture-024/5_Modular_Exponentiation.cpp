#include <bits/stdc++.h>
using namespace std;

int modularExponentiation(int x, int n, int m) {
    
}

int main() {
    int x, n;
    int m = 1e9+7;

    cout << "Enter the value of x & n : ";
    cin >> x >> n;

    cout << "x^n = " << modularExponentiation(x, n, m) << endl;
    return 0;
}