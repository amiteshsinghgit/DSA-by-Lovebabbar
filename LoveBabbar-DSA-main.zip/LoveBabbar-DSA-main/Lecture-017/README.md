# LIST OF SOLVED QUESTIONS

1.
    ```
    Write a program to perform bubble sort on an array.
    ```
    
2.
    ```
    Write a program to perform flag sort on an array.
    ```
