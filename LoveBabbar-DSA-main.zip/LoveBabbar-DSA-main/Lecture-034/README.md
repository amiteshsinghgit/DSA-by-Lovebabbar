# LIST OF SOLVED QUESTIONS

1.
    ```
    Write a program to reverse a string using recursion.
    ```

2.
    ```
    Write a program to check whether a string is palindrome or not using recursion.
    ```

3.
    ```
    Write a program to calculate exponential power using recursion.
    ```

4.
    ```
    Write a program to perform bubble sort using recursion on an array.
    ```

5.
    ```
    Write a program to perform selection sort using recursion on an array.
    ```

6.
    ```
    Write a program to perform insertion sort using recursion on an array.
    ```
