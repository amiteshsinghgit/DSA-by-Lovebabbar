# LIST OF SOLVED QUESTIONS

1.
    ```
    Write a program to find the first and last occurrence of an element in a sorted array. (Leetcode : Problem No 34)
    ```
2.
    ```
    Write a program to total number of occurrences of an element in a sorted array.
    ```
3.
    ```
    Write a program to find the peak element of a mountain array. (Leetcode : Problem No 852)
    ```
4.
    ```
    Write a program to find the pivot element of an array. (Leetcode : Problem No 724)
    ```
