# LIST OF SOLVED QUESTIONS

1.
    ```
    Write a program to declare a 2D array dynamically and perform its I/O operations.
    ```

2.
    ```
    Write a program to create a jaggered array dynamically and perform its I/O operations.
    ```
