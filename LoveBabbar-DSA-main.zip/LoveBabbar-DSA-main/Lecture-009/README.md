# LIST OF SOLVED QUESTIONS

1.
    ```
    Write a program to implement an array.
    ```
    
2.
    ```
    Write a program to find the minimum and maximum element in an array.
    ```
    
3.
    ```
    Write a program to show the scope of an array.
    ```

4.
    ```
    Write a program to find the sum of all elements an array.
    ```
    
5.
    ```
    Write a program to implement linear search in an array.
    ```
6.
    ```
    Write a program to reverse an array.
    ```
