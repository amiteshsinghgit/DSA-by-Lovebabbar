# LIST OF SOLVED QUESTIONS

1.
    ```
    Write a program to perform insertion sort on an array.
    ```
